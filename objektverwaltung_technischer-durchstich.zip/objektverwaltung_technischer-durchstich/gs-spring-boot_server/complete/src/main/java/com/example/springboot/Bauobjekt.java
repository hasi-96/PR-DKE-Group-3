package com.example.springboot;

public class Bauobjekt {
    private String name;
    private String type;

    // Constructor without parameters
    public Bauobjekt() {
    }

    // Constructor with parameters
    public Bauobjekt(String name, String type) {
        this.name = name;
        this.type = type;
    }

    // Getter for name
    public String getName() {
        return name;
    }

    // Setter for name
    public void setName(String name) {
        this.name = name;
    }

    // Getter for type
    public String getType() {
        return type;
    }

    // Setter for type
    public void setType(String type) {
        this.type = type;
    }
}
