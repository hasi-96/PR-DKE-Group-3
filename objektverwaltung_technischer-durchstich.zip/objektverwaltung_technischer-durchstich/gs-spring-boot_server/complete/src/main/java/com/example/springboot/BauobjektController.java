package com.example.springboot;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.ArrayList;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.beans.factory.annotation.Autowired;

@CrossOrigin(maxAge = 3600)
@RestController
@RequestMapping("/bauobjekt")
public class BauobjektController {

    // Inject your service or repository here
    @Autowired
    private JdbcTemplate jdbcTemplate;

    @CrossOrigin(origins = "http://localhost:4200")
    @PostMapping
    public ResponseEntity<String> createBauobjekt(@RequestBody Bauobjekt bauobjekt) {
        // Implement creation logic

        jdbcTemplate.update("INSERT INTO Bauobjekte(name, type) VALUES(?,?)", bauobjekt.getName(), bauobjekt.getType());

        return ResponseEntity.ok(bauobjekt.getName());
    }
/*
    @GetMapping("/{id}")
    public ResponseEntity<Bauobjekt> getBauobjektById(@PathVariable Long id) {
        // Implement retrieval logic


        return ResponseEntity.ok(bauobjekt);
    }
*/

    @CrossOrigin(origins = "http://localhost:4200", allowedHeaders = "Requestor-Type", exposedHeaders = "X-Get-Header")
    @GetMapping
    public ResponseEntity<List<Bauobjekt>> getAllBauobjekts() {
        // Implement retrieval of all objects logic

        String sql = "SELECT * FROM Bauobjekte";
        List<Bauobjekt> bauobjekte = jdbcTemplate.query(sql, BeanPropertyRowMapper.newInstance(Bauobjekt.class));

        return ResponseEntity.ok(bauobjekte);
    }

    /*
    @PutMapping("/{id}")
    public ResponseEntity<Bauobjekt> updateBauobjekt(@PathVariable Long id, @RequestBody Bauobjekt bauobjekt) {
        // Implement update logic
        return ResponseEntity.ok(updatedBauobjekt);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteBauobjekt(@PathVariable Long id) {
        // Implement deletion logic
        return ResponseEntity.ok().build();
    }
    */
}
