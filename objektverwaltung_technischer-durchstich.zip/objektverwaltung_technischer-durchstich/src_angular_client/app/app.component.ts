import { Component } from '@angular/core';
import { Observable } from "rxjs";
import { of } from 'rxjs';
import { BauobjektService } from "./bauobjekt.service";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})

export class AppComponent {
  title = 'objektverwaltung';

   bauobjekte$: Observable<any>;

   constructor(private bauobjektData: BauobjektService)
   {
     this.bauobjekte$ = this.bauobjektData.getBauobjekte();
	}

  onButtonClickAdd(n:string, t:string): void {
	  this.bauobjektData.addBauobjekt(n, t);
  }
  
    onButtonClickUpdate(): void {

	  this.bauobjekte$ = this.bauobjektData.getBauobjekte();
  }
}
