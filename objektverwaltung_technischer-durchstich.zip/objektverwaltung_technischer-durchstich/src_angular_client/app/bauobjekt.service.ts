import { Injectable } from '@angular/core';
import { from, Observable, of, throwError, catchError } from 'rxjs';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';

export interface Bauobjekt {
  name: string;
  type: string;
}

@Injectable({
  providedIn: 'root'
})

export class BauobjektService {

    constructor(private http: HttpClient){}
	
	bauobjekts: Bauobjekt[] = [];

	getBauobjekte()
	{
		 return this.http.get('http://localhost:8080/bauobjekt').pipe(
			catchError(error => this.handleError(error)));
	}
	
	private handleError(error: HttpErrorResponse): Observable<any> {
    // If error, fallback to fetching data from IndexedDB
    if (error.status !== 200) {
      return from(this.fetchFromIndexedDB());
    }
    // Re-throw the error if it's not a network error
    return throwError(error);
  }
  
	private fetchFromIndexedDB(): Observable<any> {

		return of(this.bauobjekts);
	}
	
	addBauobjekt(n: string, t: string)
	{
		const myBauobjekt: Bauobjekt = {
		  name: n,
		  type: t
		};
		
		return this.http.post<any>('http://localhost:8080/bauobjekt', myBauobjekt).pipe(
		  catchError(error => {
			this.saveToIndexedDB(myBauobjekt);
			return throwError(() => new Error('Failed to send Bauobjekt, data saved locally'));
		  })
		).subscribe({
		  next: data => {
			// Handle successful response here
		  },
		  error: error => {
			// Handle error here
			console.error('There was an error!', error);
		  }
		});
	}
	private saveToIndexedDB(myBauobjekt: Bauobjekt) {
		this.bauobjekts.push(myBauobjekt);  
	}
}
